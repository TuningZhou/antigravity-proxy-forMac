#!/usr/bin/env bash
# ==============================================================================
# Antigravity-Proxy for macOS —— 免安装双击启动器
#
# 使用方式：
#   1) 在“访达”里双击本文件（首次请“右键 → 打开”，以通过 Gatekeeper 提示）
#   2) 在终端执行：./Antigravity-Proxy.command [app|agy] [agy 参数...]
#   3) 直接把 Antigravity.app 拖到本启动器图标上，可立即代理启动
#
# 重要：本启动器不会修改官方 App。首次使用会在官方 App 同目录自动复制一份
#   “Antigravity IDE TUN.app”（或“Antigravity TUN.app”），签名补丁只打在
#   副本上，日常也只启动副本；原件保持官方原始签名，可随时照常双击使用。
# ==============================================================================

# Finder 双击 .command 时 PATH 很短，先补全常见路径
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"

# 解析脚本自身真实路径（兼容从别名/软链启动）
SCRIPT_PATH="${BASH_SOURCE[0]:-$0}"
while [ -L "${SCRIPT_PATH}" ]; do
    LINK_DIR="$(cd "$(dirname "${SCRIPT_PATH}")" && pwd)"
    SCRIPT_PATH="$(readlink "${SCRIPT_PATH}")"
    [[ "${SCRIPT_PATH}" != /* ]] && SCRIPT_PATH="${LINK_DIR}/${SCRIPT_PATH}"
done
APP_HOME="$(cd "$(dirname "${SCRIPT_PATH}")" && pwd)"
DYLIB="${APP_HOME}/libantigravity_proxy.dylib"
PATCH_SCRIPT="${APP_HOME}/mac-patch-app.sh"
CONFIG="${APP_HOME}/config.json"
LOG_DIR="${APP_HOME}/logs"

if [ -t 1 ]; then
    C_RESET="\033[0m"; C_BOLD="\033[1m"; C_GREEN="\033[32m"; C_YELLOW="\033[33m"; C_RED="\033[31m"; C_CYAN="\033[36m"
else
    C_RESET=""; C_BOLD=""; C_GREEN=""; C_YELLOW=""; C_RED=""; C_CYAN=""
fi

# 本文件夹位于“桌面/文稿/下载”等 TCC 隐私保护目录时给出搬迁提醒
tcc_warn_if_needed() {
    case "${APP_HOME}/" in
        "$HOME/Desktop/"*|"$HOME/Documents/"*|"$HOME/Downloads/"*)
            echo -e "${C_YELLOW}[重要提醒] 本文件夹当前位于系统隐私保护目录（桌面/文稿/下载）内。${C_RESET}"
            echo "  macOS 会阻止提权后的系统进程读取这里的文件（报错 Operation not permitted），"
            echo "  代理副本启动时加载本目录的动态库也可能被系统拦截，导致代理不生效。"
            echo "  请先退出本启动器，把整个“Antigravity-Proxy-macOS”文件夹移动到非保护目录，"
            echo -e "  例如“用户应用程序”目录 ${C_BOLD}~/Applications${C_RESET}（没有该文件夹可自行新建），再重新双击运行。"
            echo ""
            ;;
    esac
}

print_header() {
    clear 2>/dev/null || true
    echo -e "${C_CYAN}${C_BOLD}==================================================${C_RESET}"
    echo -e "${C_CYAN}${C_BOLD}   Antigravity-Proxy for macOS  透明代理启动器${C_RESET}"
    echo -e "${C_CYAN}${C_BOLD}==================================================${C_RESET}"
    echo ""
    tcc_warn_if_needed
}

pause() {
    echo ""
    read -r -p "按回车键返回菜单..." _dummy
}

# 读取配置中的代理端口（仅用于界面展示，非精确 JSON 解析）
current_proxy_port() {
    [ -f "${CONFIG}" ] || { echo "未找到 config.json"; return; }
    grep -A4 '"proxy"' "${CONFIG}" 2>/dev/null \
        | grep '"port"' | head -n 1 \
        | sed -E 's/[^0-9]//g'
}

# shell 单引号安全转义
shquote() {
    local s="$1"
    echo "'${s//\'/\'\\\'\'}'"
}

# 从任意路径提取所属 .app 目录
derive_app_dir() {
    local p="$1"
    case "${p}" in
        *.app) echo "${p%/}"; return 0 ;;
        *.app/*) echo "${p%%.app/*}.app"; return 0 ;;
    esac
    return 1
}

# 从 .app 包内解析真实可执行文件路径
resolve_app_executable() {
    local app_dir="$1" exe
    exe="$(/usr/libexec/PlistBuddy -c 'Print:CFBundleExecutable' "${app_dir}/Contents/Info.plist" 2>/dev/null || true)"
    if [ -n "${exe}" ] && [ -f "${app_dir}/Contents/MacOS/${exe}" ]; then
        echo "${app_dir}/Contents/MacOS/${exe}"
    fi
}

# 查找官方 Antigravity 原件（DIRECT_TARGET 优先，其次常见位置，最后 Spotlight）
# 注意：自动发现必须排除“... TUN.app”副本——副本由补丁状态单独管理
find_antigravity_app() {
    _tun_is_original_path() { case "$(macpatch_app_stem "$1" 2>/dev/null || basename "$1" .app)" in
        *" TUN") return 1 ;; *) return 0 ;; esac; }
    if [ -n "${DIRECT_TARGET:-}" ]; then
        local d="${DIRECT_TARGET}"
        if [ -d "${d}" ] && [[ "${d}" == *.app ]]; then
            echo "${d%/}"; return 0
        fi
        local app_of
        app_of="$(derive_app_dir "${d}" || true)"
        if [ -n "${app_of}" ] && [ -d "${app_of}" ]; then
            echo "${app_of}"; return 0
        fi
    fi
    local cand found
    for cand in \
        "/Applications/Antigravity IDE.app" \
        "/Applications/Antigravity.app" \
        "${HOME}/Applications/Antigravity IDE.app" \
        "${HOME}/Applications/Antigravity.app"; do
        [ -d "${cand}" ] && { echo "${cand}"; return 0; }
    done
    if command -v mdfind >/dev/null 2>&1; then
        found="$(mdfind "(kMDItemCFBundleIdentifier == 'com.google.antigravity-ide') || (kMDItemCFBundleIdentifier == 'com.antigravity.desktop')" 2>/dev/null || true)"
        while IFS= read -r d; do
            [ -n "${d}" ] && [ -d "${d}" ] && _tun_is_original_path "${d}" && { echo "${d%/}"; return 0; }
        done <<< "${found}"
        found="$(mdfind "kMDItemContentType == 'com.apple.application-bundle' && (kMDItemFSName == 'Antigravity.app' || kMDItemFSName == 'Antigravity IDE.app')" 2>/dev/null || true)"
        while IFS= read -r d; do
            [ -n "${d}" ] && [ -d "${d}" ] && _tun_is_original_path "${d}" && { echo "${d%/}"; return 0; }
        done <<< "${found}"
    fi
    return 1
}

find_agy() {
    local p
    p="$(command -v agy 2>/dev/null || true)"
    [ -n "${p}" ] && { echo "${p}"; return; }
    for p in "${HOME}/.antigravity/bin/agy" "${HOME}/.local/bin/agy" \
             "/opt/homebrew/bin/agy" "/usr/local/bin/agy"; do
        [ -f "${p}" ] && { echo "${p}"; return; }
    done
}

check_environment() {
    if [ ! -f "${DYLIB}" ]; then
        echo -e "${C_RED}[错误] 未找到动态库: ${DYLIB}${C_RESET}"
        echo "请重新下载并完整解压本压缩包。"
        return 1
    fi
    if [ ! -f "${CONFIG}" ]; then
        echo -e "${C_RED}[错误] 未找到配置文件: ${CONFIG}${C_RESET}"
        return 1
    fi
    if [ ! -f "${PATCH_SCRIPT}" ]; then
        echo -e "${C_RED}[错误] 未找到补丁脚本: ${PATCH_SCRIPT}${C_RESET}"
        echo "请重新下载并完整解压本压缩包。"
        return 1
    fi
    if ! command -v codesign >/dev/null 2>&1; then
        echo -e "${C_RED}[错误] 未找到 codesign 工具。${C_RESET}"
        echo "请先安装 Apple“命令行开发者工具”：在“终端”执行 xcode-select --install 后重试。"
        return 1
    fi
    # 架构匹配检查
    local host_arch lib_archs
    host_arch="$(uname -m)"
    lib_archs="$(lipo -archs "${DYLIB}" 2>/dev/null || echo "")"
    case " ${lib_archs} " in
        *" ${host_arch} "*) : ;;
        *)
            echo -e "${C_YELLOW}[警告] 动态库架构(${lib_archs})与本机(${host_arch})不匹配。${C_RESET}"
            echo "请下载 universal2 通用版本或对应架构的安装包。"
            ;;
    esac
    return 0
}

# 计算 seed（可能是官方原件或 TUN 副本）对应的原件/副本路径，结果写入全局变量
resolve_app_pair() {
    local seed="${1%/}"
    if macpatch_is_tun_app "${seed}"; then
        COPY_APP="${seed}"
        ORIG_APP="$(macpatch_orig_sibling "${seed}")"
        [ -d "${ORIG_APP}" ] || ORIG_APP=""
    else
        ORIG_APP="${seed}"
        COPY_APP="$(macpatch_tun_sibling "${seed}")"
    fi
}

# 以系统管理员权限执行“复制副本 + 签名补丁”（目标在 /Applications 等无权目录时），
# 完成后把副本与冒烟产生的日志改回当前用户属主。
# 注意：macOS 的“文稿/桌面/下载”受 TCC 隐私保护，提权后的 root 进程没有这些
# 目录的访问授权（root 也受 TCC 约束），直接执行位于其中的脚本会报
# “Operation not permitted (126)”。因此先把补丁脚本与 dylib 暂存到
# 系统中立临时目录 /private/tmp，再让提权进程执行暂存副本。
run_app_prepare_as_admin() {
    local seed="$1" recreate="$2" uid gid inner esc rc=0 stage patch_tmp dylib_tmp
    uid="$(id -u)"; gid="$(id -g)"
    resolve_app_pair "${seed}"
    stage="$(mktemp -d /private/tmp/agy-proxy-admin.XXXXXX 2>/dev/null || mktemp -d -t agyproxy)" || return 1
    chmod 755 "${stage}" 2>/dev/null
    patch_tmp="${stage}/mac-patch-app.sh"
    dylib_tmp="${stage}/libantigravity_proxy.dylib"
    if ! /bin/cp "${PATCH_SCRIPT}" "${patch_tmp}" || ! /bin/cp "${DYLIB}" "${dylib_tmp}"; then
        rm -rf "${stage}" 2>/dev/null
        echo "[错误] 无法准备提权临时文件: ${stage}" >&2
        return 1
    fi
    chmod 755 "${patch_tmp}" "${dylib_tmp}" 2>/dev/null
    if [ "${recreate}" = "recreate" ]; then
        inner="/bin/bash $(shquote "${patch_tmp}") --recreate $(shquote "${seed}") $(shquote "${dylib_tmp}"); rc=\$?"
    else
        inner="/bin/bash $(shquote "${patch_tmp}") $(shquote "${seed}") $(shquote "${dylib_tmp}"); rc=\$?"
    fi
    inner="${inner}; /usr/sbin/chown -R ${uid}:${gid} $(shquote "${COPY_APP}") 2>/dev/null; /usr/sbin/chown -R ${uid}:${gid} $(shquote "${LOG_DIR}") 2>/dev/null; exit \$rc"
    esc="${inner//\\/\\\\}"; esc="${esc//\"/\\\"}"
    /usr/bin/osascript -e "do shell script \"${esc}\" with administrator privileges" || rc=$?
    rm -rf "${stage}" 2>/dev/null
    return ${rc}
}

# 提权/补丁失败时，针对 126（TCC 隐私保护拦截）给出可操作提示
admin_fail_hint() {
    local rc="$1"
    [ "${rc}" = "126" ] || return 0
    echo -e "${C_YELLOW}返回码 126（Operation not permitted）通常是 macOS 隐私保护拦截：${C_RESET}"
    echo "  · 请把整个“Antigravity-Proxy-macOS”文件夹移出“桌面/文稿/下载”后重试（推荐放到 ~/Applications）；"
    echo "  · 或在“系统设置 → 隐私与安全性 → 完全磁盘访问权限”中允许“终端”，退出终端后重开再试。"
}

# 确保目标已具备注入条件；需要补丁时自动执行（仅会执行一次）
# 返回 0=就绪，非 0=不可启动（用于 agy 等裸可执行文件，就地补丁）
ensure_patch() {
    local target="$1" rc tries ans

    if ! macpatch_target_needs_patch "${target}"; then
        return 0
    fi

    echo ""
    echo -e "${C_YELLOW}--------------------------------------------------${C_RESET}"
    echo -e "${C_BOLD}首次使用需要执行一次“本地签名补丁”${C_RESET}"
    echo "--------------------------------------------------"
    echo "该程序启用了 Hardened Runtime，默认禁止任何第三方动态库注入，"
    echo "代理必须先给它补上本机签名权限："
    echo "  · 仅在本机重签名，加入“允许注入”权限，不联网、不上传、不改功能"
    echo "  · 只需要执行一次；程序升级/重装后需重新补丁"
    echo ""

    # 目标在运行时无法重签名，引导用户退出后重试
    tries=0
    while macpatch_is_running "${target}"; do
        echo -e "${C_YELLOW}检测到目标程序正在运行。${C_RESET}"
        echo "请先完全退出它（⌘Q）。"
        read -r -p "退出后按回车自动继续（输入 s 跳过补丁）: " ans
        [ "${ans}" = "s" ] && return 4
        tries=$((tries + 1))
        [ "${tries}" -ge 5 ] && return 4
    done

    # 可写：直接补丁；不可写：弹出系统密码框用管理员权限补丁
    set +e
    if [ -w "$(macpatch_resolve_binary "${target}")" ]; then
        macpatch_ensure_target "${target}" "${DYLIB}"
        rc=$?
    else
        echo "目标目录当前用户不可写，将弹出系统授权框请求管理员权限..."
        run_app_prepare_as_admin "${target}"
        rc=$?
    fi
    set -e

    case "${rc}" in
        0)
            echo -e "${C_GREEN}签名补丁完成，以后启动无需再次操作（程序升级除外）。${C_RESET}"
            return 0 ;;
        3)
            echo -e "${C_RED}[错误] 没有写权限且未获得管理员授权。${C_RESET}"
            return 3 ;;
        4)
            echo -e "${C_RED}[错误] 程序仍在运行，请退出后重试。${C_RESET}"
            return 4 ;;
        5)
            echo -e "${C_RED}[错误] 签名补丁或注入验证失败。${C_RESET}"
            echo "可把以上 [patch] 输出连同 ${LOG_DIR} 里的日志反馈给项目作者。"
            return 5 ;;
        6)
            echo -e "${C_RED}[错误] 系统缺少 codesign，请先执行 xcode-select --install。${C_RESET}"
            return 6 ;;
        *)
            echo -e "${C_RED}[错误] 补丁未成功（返回码 ${rc}）。${C_RESET}"
            admin_fail_hint "${rc}"
            return "${rc}" ;;
    esac
}

# 交互准备官方 App 的 TUN 副本：复制 →（版本落后时重建）→ 签名补丁。
# 成功后全局 EFFECTIVE_APP 为实际应启动的副本路径；官方原件始终不被修改。
ensure_app_ready() {
    local seed="${1%/}" state tries ans rc parent ov cv do_recreate=""
    resolve_app_pair "${seed}"

    state="$(macpatch_tun_status_word "${seed}")"
    case "${state}" in
        ready)
            EFFECTIVE_APP="${COPY_APP}"
            return 0 ;;
        invalid|not-antigravity)
            ensure_patch "${seed}" || return $?
            EFFECTIVE_APP="${seed}"
            return 0 ;;
    esac

    echo ""
    echo -e "${C_YELLOW}--------------------------------------------------${C_RESET}"
    echo -e "${C_BOLD}首次使用：准备“代理专用副本”（官方原件不会被修改）${C_RESET}"
    echo "--------------------------------------------------"
    echo "  官方原件（保持官方签名）: ${ORIG_APP:-未找到}"
    echo "  代理副本（打补丁/启动）: ${COPY_APP}"
    echo ""
    case "${state}" in
        missing)
            echo "将在官方程序同目录复制一份“$(basename "${COPY_APP}")”，"
            echo "签名补丁只打在副本上。副本与原件共用登录状态，无需重新登录。" ;;
        needs-patch)
            echo "代理副本已存在，需要对其执行一次本地 ad-hoc 签名补丁"
            echo "（不联网、不上传、不改功能；只需一次，升级后重做）。" ;;
        outdated)
            ov="$(macpatch_app_version "${ORIG_APP}")"
            cv="$(macpatch_app_version "${COPY_APP}")"
            echo -e "${C_YELLOW}官方原件已升级（副本 ${cv} / 原件 ${ov}），建议重建副本。${C_RESET}"
            read -r -p "现在删除旧副本并重新复制+补丁吗？[Y/n]（n=继续启动旧版本）: " ans
            case "${ans}" in
                n|N|no|NO)
                    echo "跳过重建，直接为旧版本副本补签名..."
                    set +e
                    macpatch_ensure_target "${COPY_APP}" "${DYLIB}"
                    rc=$?
                    set -e
                    if [ "${rc}" -eq 0 ]; then EFFECTIVE_APP="${COPY_APP}"; return 0; fi
                    echo -e "${C_RED}[错误] 旧副本补丁失败（返回码 ${rc}），可重新选 1 并同意重建。${C_RESET}"
                    return 1 ;;
                *) do_recreate="recreate" ;;
            esac ;;
    esac
    echo ""

    # 原件或副本正在运行都会导致单实例冲突/无法重签，引导先退出
    tries=0
    while macpatch_is_running_related "${seed}"; do
        echo -e "${C_YELLOW}检测到 Antigravity（原件或副本）正在运行。${C_RESET}"
        echo "请先完全退出它（在窗口按 ⌘Q，或菜单栏图标 → Quit）。"
        read -r -p "退出后按回车自动继续（输入 s 跳过）: " ans
        [ "${ans}" = "s" ] && return 4
        tries=$((tries + 1))
        [ "${tries}" -ge 5 ] && return 4
    done

    # 父目录/副本可写就直接执行；/Applications 等不可写位置走系统授权框
    parent="$(dirname "${COPY_APP}")"
    set +e
    if [ -w "${parent}" ] && { [ ! -d "${COPY_APP}" ] || [ -w "${COPY_APP}" ]; }; then
        if [ "${do_recreate}" = "recreate" ]; then
            macpatch_ensure_app_target "${seed}" "${DYLIB}" recreate
        else
            macpatch_ensure_app_target "${seed}" "${DYLIB}"
        fi
        rc=$?
    else
        echo "在“${parent}”创建副本需要管理员权限，将弹出系统授权框（与安装软件相同）..."
        run_app_prepare_as_admin "${seed}" "${do_recreate}"
        rc=$?
    fi
    set -e

    case "${rc}" in
        0)
            EFFECTIVE_APP="${COPY_APP}"
            echo -e "${C_GREEN}代理副本已就绪。以后每次选 1 都会直接启动这个副本。${C_RESET}"
            return 0 ;;
        3)
            echo -e "${C_RED}[错误] 没有写权限且未获得管理员授权。${C_RESET}"
            echo "也可以把官方 Antigravity 复制到“个人应用程序”（~/Applications）后重试。"
            return 3 ;;
        4)
            echo -e "${C_RED}[错误] Antigravity 仍在运行，请退出后重试。${C_RESET}"
            return 4 ;;
        5)
            echo -e "${C_RED}[错误] 复制副本或签名补丁失败。${C_RESET}"
            echo "可把以上 [patch] 输出连同 ${LOG_DIR} 里的日志反馈给项目作者。"
            return 5 ;;
        6)
            echo -e "${C_RED}[错误] 系统缺少 codesign，请先执行 xcode-select --install。${C_RESET}"
            return 6 ;;
        7)
            echo -e "${C_RED}[错误] 副本版本与原件不一致，请重新选 1 并同意重建副本。${C_RESET}"
            return 7 ;;
        *)
            echo -e "${C_RED}[错误] 准备未成功（返回码 ${rc}）。${C_RESET}"
            admin_fail_hint "${rc}"
            return "${rc}" ;;
    esac
}

# 以注入环境启动 .app（LaunchServices 会自动重建完整进程树）
# 始终启动“代理专用副本”，官方原件不触碰
launch_app() {
    local seed="${1:-}" app_dir exe
    if [ -z "${seed}" ]; then
        app_dir="$(find_antigravity_app || true)"
    else
        app_dir="${seed%/}"
    fi
    if [ -z "${app_dir}" ]; then
        echo -e "${C_RED}[错误] 没有找到 Antigravity.app。${C_RESET}"
        echo ""
        echo "请尝试以下任一方式："
        echo "  1) 把 Antigravity.app 拖到本启动器（${0##*/}）图标上再松开"
        echo "  2) 确认 Antigravity 已安装到 /Applications 或“应用程序”文件夹"
        return 1
    fi

    ensure_app_ready "${app_dir}" || return 1
    exe="$(resolve_app_executable "${EFFECTIVE_APP}")"

    echo -e "${C_GREEN}[启动] 正在以透明代理模式启动 Antigravity（代理专用副本）...${C_RESET}"
    echo "       副本: ${EFFECTIVE_APP}"
    [ -n "${ORIG_APP:-}" ] && echo "       原件保持原样，未做任何修改"
    echo "       程序: ${exe}"
    echo "       代理配置: ${CONFIG}"
    open -n \
        --env DYLD_INSERT_LIBRARIES="${DYLIB}" \
        --env DYLD_FORCE_FLAT_NAMESPACE=1 \
        "${EFFECTIVE_APP}" ${@:2}
    echo -e "${C_GREEN}已启动。本终端窗口现在可以关闭，Antigravity 会继续运行。${C_RESET}"
    echo "       代理日志: ${LOG_DIR}"
}

launch_agy() {
    local bin
    bin="$(find_agy)"
    if [ -z "${bin}" ]; then
        echo -e "${C_RED}[错误] 没有找到 agy 命令。${C_RESET}"
        echo "请先安装 Antigravity CLI（agy），或在其安装后重试。"
        return 1
    fi
    ensure_patch "${bin}" || return 1
    echo -e "${C_GREEN}[启动] agy 透明代理模式: ${bin} $*${C_RESET}"
    echo ""
    DYLD_INSERT_LIBRARIES="${DYLIB}" DYLD_FORCE_FLAT_NAMESPACE=1 exec "${bin}" "$@"
}

# 非交互参数直通：./Antigravity-Proxy.command /path/to/Antigravity.app
DIRECT_TARGET=""
if [ $# -gt 0 ] && [ "$1" != "app" ] && [ "$1" != "agy" ]; then
    DIRECT_TARGET="$1"
    shift
fi

check_environment || { echo ""; read -r -p "按回车键退出..." _dummy; exit 1; }

# 加载补丁函数库
# shellcheck source=mac-patch-app.sh
source "${PATCH_SCRIPT}"

# 非交互（拖放/命令行参数）流程不会经过菜单，这里同样提醒一次
if [ -n "${DIRECT_TARGET}" ] || [ $# -gt 0 ]; then
    tcc_warn_if_needed
fi

if [ -n "${DIRECT_TARGET}" ]; then
    if [ -d "${DIRECT_TARGET}" ] || derive_app_dir "${DIRECT_TARGET}" >/dev/null 2>&1; then
        launch_app "${DIRECT_TARGET}" "$@"
    else
        # 裸可执行文件：走 agy 同样的注入路径
        if [ ! -e "${DIRECT_TARGET}" ]; then
            echo "[错误] 目标不存在: ${DIRECT_TARGET}"
            read -r -p "按回车键退出..." _dummy
            exit 1
        fi
        ensure_patch "${DIRECT_TARGET}" || { read -r -p "按回车键退出..." _dummy; exit 1; }
        DYLD_INSERT_LIBRARIES="${DYLIB}" DYLD_FORCE_FLAT_NAMESPACE=1 exec "${DIRECT_TARGET}" "$@"
    fi
    exit $?
fi

if [ $# -gt 0 ]; then
    case "$1" in
        app) shift; launch_app "" "$@" ;;
        agy) shift; launch_agy "$@" ;;
        *)    echo "[错误] 未知参数: $1（可选: app / agy）"; exit 1 ;;
    esac
    exit $?
fi

# 交互菜单
while true; do
    print_header
    PORT="$(current_proxy_port)"
    APP_DIR="$(find_antigravity_app || true)"
    PATCH_STATE="未找到 Antigravity.app"
    COPY_PATH=""
    if [ -n "${APP_DIR}" ]; then
        COPY_PATH="$(macpatch_tun_sibling "${APP_DIR}")"
        state_word="$(macpatch_tun_status_word "${APP_DIR}" 2>/dev/null || echo invalid)"
        case "${state_word}" in
            missing)
                PATCH_STATE="${C_YELLOW}尚未创建代理副本（选 1 自动复制“$(basename "${COPY_PATH}")”，官方原件不改动）${C_RESET}" ;;
            outdated)
                PATCH_STATE="${C_YELLOW}代理副本版本落后于官方原件（选 1 可自动重建）${C_RESET}" ;;
            needs-patch)
                PATCH_STATE="${C_YELLOW}代理副本需要首次签名补丁（选 1 自动完成）${C_RESET}" ;;
            ready)
                PATCH_STATE="${C_GREEN}代理副本已就绪（补丁已应用）${C_RESET}" ;;
            *)
                PATCH_STATE="无法识别目标: ${APP_DIR}" ;;
        esac
    fi
    echo -e " 配置文件: ${C_BOLD}${CONFIG}${C_RESET}"
    echo -e " 代理端口: ${C_BOLD}${PORT:-未知}${C_RESET}（如不正确请选 3 修改）"
    echo -e " 副本状态: $(echo -e "${PATCH_STATE}")"
    if [ -n "${APP_DIR}" ]; then
        echo "           官方原件: ${APP_DIR}（不会被修改）"
        echo "           代理副本: ${COPY_PATH}"
    fi
    echo ""
    echo -e "  ${C_BOLD}1${C_RESET}) 启动 Antigravity IDE（透明代理模式，使用代理副本）"
    echo -e "  ${C_BOLD}2${C_RESET}) 启动 agy 命令行（status / login 等）"
    echo -e "  ${C_BOLD}3${C_RESET}) 编辑配置文件 config.json（改代理端口）"
    echo -e "  ${C_BOLD}4${C_RESET}) 查看代理日志（logs 文件夹）"
    echo -e "  ${C_BOLD}5${C_RESET}) 打开《使用说明》"
    echo -e "  ${C_BOLD}6${C_RESET}) 重新检测/创建/修复代理副本"
    echo -e "  ${C_BOLD}0${C_RESET}) 退出"
    echo ""
    read -r -p "请输入选项编号后回车: " choice
    case "${choice}" in
        1)
            launch_app
            pause ;;
        2)
            echo ""
            read -r -p "请输入 agy 参数（直接回车默认 status，例如 login）: " agy_args
            # 故意不加引号：允许用户输入多个参数
            launch_agy ${agy_args:-status}
            pause ;;
        3)
            open -e "${CONFIG}"
            echo "已用“文本编辑”打开 config.json，改完记得保存（Cmd+S）。"
            pause ;;
        4)
            if [ -d "${LOG_DIR}" ]; then
                open "${LOG_DIR}"
            else
                echo "尚未生成日志。先启动一次 Antigravity 后再查看。"
            fi
            pause ;;
        5)
            if [ -f "${APP_HOME}/使用说明.txt" ]; then
                open -e "${APP_HOME}/使用说明.txt"
            else
                echo "未找到 使用说明.txt。"
            fi
            pause ;;
        6)
            if [ -z "${APP_DIR}" ]; then
                echo "没有找到 Antigravity.app，无法创建代理副本。"
            else
                state_word="$(macpatch_tun_status_word "${APP_DIR}" 2>/dev/null || echo invalid)"
                if [ "${state_word}" = "ready" ]; then
                    echo "代理副本状态正常，无需修复："
                    echo "  ${COPY_PATH}"
                    echo "（官方 Antigravity 升级后，选 1 按提示重建副本即可）"
                else
                    ensure_app_ready "${APP_DIR}" || true
                fi
            fi
            pause ;;
        0|"")
            exit 0 ;;
        *)
            echo "无效选项，请重新输入。"
            sleep 1 ;;
    esac
done
